"""Generate a small synthetic dataset so you can test the whole pipeline in minutes.

The images are NOT real leaves. Use this only to check that training, evaluation
and the web app run on your machine. Replace it with real photos for real use.

    python scripts/make_demo_data.py --out data --per-class 40
"""
import argparse
import os
import random

import numpy as np
from PIL import Image

# Base colour and speckle colour for each synthetic "disease"
CLASSES = {
    "healthy": ((60, 150, 60), (80, 180, 80)),
    "rust": ((70, 140, 60), (200, 90, 30)),
    "blight": ((70, 130, 60), (40, 30, 20)),
}


def make_image(base, speck, size, rng):
    img = np.zeros((size, size, 3), dtype=np.float32)
    img[:] = np.array(base, dtype=np.float32)
    img += rng.normal(0, 12, img.shape)  # sensor-like noise
    n_spots = rng.integers(10, 40)
    for _ in range(n_spots):
        x, y = rng.integers(0, size, 2)
        r = rng.integers(2, 9)
        img[max(0, y - r):y + r, max(0, x - r):x + r] = speck
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="data")
    parser.add_argument("--per-class", type=int, default=40)
    parser.add_argument("--size", type=int, default=256)
    args = parser.parse_args()

    rng = np.random.default_rng(0)
    random.seed(0)
    for split, count in [("train", args.per_class), ("val", max(4, args.per_class // 4))]:
        for name, (base, speck) in CLASSES.items():
            folder = os.path.join(args.out, split, name)
            os.makedirs(folder, exist_ok=True)
            for i in range(count):
                make_image(base, speck, args.size, rng).save(os.path.join(folder, f"{i:04d}.jpg"))
    print(f"Wrote demo dataset to {args.out}/ with classes {list(CLASSES)}")


if __name__ == "__main__":
    main()
