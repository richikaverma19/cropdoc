"""Turn a folder of class sub-folders (e.g. a PlantVillage download) into train/ and val/.

    python scripts/split_dataset.py --src raw_dataset --dst data --val 0.2

Expected input:  raw_dataset/<class_name>/*.jpg
Produces:        data/train/<class_name>/*.jpg and data/val/<class_name>/*.jpg
"""
import argparse
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cropdoc.core import stratified_split  # noqa: E402

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--src", required=True)
    parser.add_argument("--dst", default="data")
    parser.add_argument("--val", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    items = {}
    for name in sorted(os.listdir(args.src)):
        folder = os.path.join(args.src, name)
        if not os.path.isdir(folder):
            continue
        items[name] = [os.path.join(folder, f) for f in os.listdir(folder)
                       if os.path.splitext(f)[1].lower() in IMAGE_EXT]

    train, val = stratified_split(items, val_fraction=args.val, seed=args.seed)
    for split, pairs in [("train", train), ("val", val)]:
        for path, label in pairs:
            target = os.path.join(args.dst, split, label)
            os.makedirs(target, exist_ok=True)
            shutil.copy2(path, target)
    print(f"Copied {len(train)} train and {len(val)} val images into {args.dst}/")


if __name__ == "__main__":
    main()
