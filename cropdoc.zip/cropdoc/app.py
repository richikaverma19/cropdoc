"""Start the CropDoc web app.

    python app.py                       # http://localhost:7860
    CROPDOC_CKPT=artifacts/best.pt CROPDOC_THRESHOLD=0.7 python app.py
"""
import os

from cropdoc.predict import Classifier
from cropdoc.ui import build_ui

classifier = Classifier(
    ckpt_path=os.getenv("CROPDOC_CKPT", "artifacts/best.pt"),
    advice_path="advice.json",
    threshold=float(os.getenv("CROPDOC_THRESHOLD", "0.6")),
)
demo = build_ui(classifier, history_path=os.getenv("CROPDOC_LOG", "history.csv"))

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=int(os.getenv("PORT", "7860")))
