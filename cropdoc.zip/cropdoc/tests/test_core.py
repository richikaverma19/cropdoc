"""Tests for the framework-free logic. Run with:  python -m unittest

These run without torch, so they work on any machine.
"""
import unittest

import numpy as np
from PIL import Image

from cropdoc.core import confusion_report, decide, softmax, stratified_split, top_k
from cropdoc.quality import check_quality


class SoftmaxTests(unittest.TestCase):
    def test_probabilities_sum_to_one(self):
        probs = softmax([2.0, 1.0, -3.0])
        self.assertAlmostEqual(sum(probs), 1.0, places=9)

    def test_largest_logit_wins(self):
        probs = softmax([0.1, 5.0, 0.3])
        self.assertEqual(probs.index(max(probs)), 1)

    def test_handles_large_logits_without_overflow(self):
        probs = softmax([1000.0, 999.0])
        self.assertAlmostEqual(sum(probs), 1.0, places=9)


class DecisionTests(unittest.TestCase):
    labels = ["healthy", "rust", "blight"]

    def test_confident_prediction_is_accepted(self):
        d = decide([0.9, 0.05, 0.05], self.labels, threshold=0.6)
        self.assertTrue(d.accepted)
        self.assertEqual(d.label, "healthy")

    def test_uncertain_prediction_is_rejected(self):
        d = decide([0.4, 0.35, 0.25], self.labels, threshold=0.6)
        self.assertFalse(d.accepted)
        self.assertIsNone(d.label)

    def test_top_k_is_sorted(self):
        ranked = top_k([0.2, 0.7, 0.1], self.labels, k=2)
        self.assertEqual([name for name, _ in ranked], ["rust", "healthy"])


class SplitTests(unittest.TestCase):
    def setUp(self):
        self.items = {
            "healthy": [f"h{i}.jpg" for i in range(20)],
            "rust": [f"r{i}.jpg" for i in range(10)],
            "tiny": ["t0.jpg"],  # single image: goes to train only
        }

    def test_no_file_in_both_splits(self):
        train, val = stratified_split(self.items, val_fraction=0.2, seed=1)
        train_files = {f for f, _ in train}
        val_files = {f for f, _ in val}
        self.assertEqual(train_files & val_files, set())

    def test_every_class_with_two_or_more_images_is_in_validation(self):
        _, val = stratified_split(self.items, val_fraction=0.2, seed=1)
        val_classes = {label for _, label in val}
        self.assertEqual(val_classes, {"healthy", "rust"})

    def test_split_is_reproducible(self):
        a = stratified_split(self.items, seed=7)
        b = stratified_split(self.items, seed=7)
        self.assertEqual(a, b)

    def test_all_images_are_kept(self):
        train, val = stratified_split(self.items, seed=3)
        self.assertEqual(len(train) + len(val), 31)


class ConfusionReportTests(unittest.TestCase):
    def test_perfect_predictions(self):
        report = confusion_report([0, 1, 2, 2], [0, 1, 2, 2], ["a", "b", "c"])
        self.assertEqual(report["accuracy"], 1.0)
        self.assertTrue(all(row["f1"] == 1.0 for row in report["per_class"]))

    def test_precision_and_recall(self):
        # class 0 is predicted for 3 items; only 2 of them are truly class 0
        y_true = [0, 0, 1, 1]
        y_pred = [0, 0, 0, 1]
        report = confusion_report(y_true, y_pred, ["a", "b"])
        a = report["per_class"][0]
        self.assertAlmostEqual(a["precision"], 2 / 3, places=4)
        self.assertAlmostEqual(a["recall"], 1.0, places=4)
        self.assertAlmostEqual(report["accuracy"], 0.75, places=4)


class QualityTests(unittest.TestCase):
    def test_dark_image_is_flagged(self):
        dark = Image.new("RGB", (300, 300), (5, 5, 5))
        self.assertIn("the photo is too dark", check_quality(dark))

    def test_flat_image_is_flagged_as_blurry(self):
        flat = Image.new("RGB", (300, 300), (120, 120, 120))
        self.assertIn("the photo looks blurry", check_quality(flat))

    def test_sharp_textured_image_passes(self):
        rng = np.random.default_rng(0)
        noisy = Image.fromarray(rng.integers(0, 256, (300, 300, 3), dtype=np.uint8))
        self.assertEqual(check_quality(noisy), [])


if __name__ == "__main__":
    unittest.main()
