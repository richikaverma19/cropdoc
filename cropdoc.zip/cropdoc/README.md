# CropDoc: Leaf Disease Detector

**Domain:** Deep Learning for Computer Vision
**Real-world problem:** Farmers often find crop disease only after it has spread. A phone photo of a leaf can give an early, first-pass answer, but many farmers have no agronomist nearby. CropDoc classifies a leaf photo as healthy or as a likely disease, reports how confident it is, says "not sure" when it isn't, and gives practical next steps.

---

## 1. The big idea (concept first)

Training a deep network from scratch needs millions of images. Farmers do not have that. CropDoc uses **transfer learning**:

```
  ImageNet (1.2M photos of everyday objects)
          │
          ▼  pretrained MobileNetV3-Small already knows edges, textures, shapes
  ┌─────────────────────────┐
  │  feature extractor      │  ← kept (already knows how to "see")
  ├─────────────────────────┤
  │  classifier head        │  ← replaced with a new layer: 3 (or N) crop classes
  └─────────────────────────┘
          │
          ▼  fine-tune on a few thousand leaf photos
     "rust, 83%"  ──►  accepted if ≥ threshold, otherwise "Not sure"
```

The pipeline end to end:

```
  leaf photo ─► quality gate ─► preprocess ─► CNN ─► softmax ─► confidence gate ─► advice
  (too dark?      (blurry?       (resize,      (MobileNetV3)   (probabilities)   (≥ 60%?)
   too blurry?    → retake)      normalise)                                     else "not sure")
```

Why each piece exists:

| Piece | Why it matters in the field |
|---|---|
| MobileNetV3-Small | Small and fast: runs on a mid-range phone, a Raspberry Pi, or a laptop CPU |
| Augmentation (crops, flips, colour jitter) | Real photos vary in light, angle and framing |
| Label smoothing + early stopping | Prevents over-confident guesses and overfitting |
| Quality gate | Blurry or dark photos are rejected with a helpful message instead of a wrong answer |
| Confidence threshold | A wrong confident answer is worse than "not sure" |
| ONNX export | Lets the model run without PyTorch, e.g. in a mobile or offline app |

---

## 2. Project structure

```
cropdoc/
├── app.py                    # Gradio web app (upload → diagnosis)
├── advice.json               # Treatment advice per class (edit freely)
├── cropdoc/
│   ├── core.py               # softmax, confidence decision, split, metrics (no torch)
│   ├── quality.py            # blur / darkness check (numpy + Pillow)
│   ├── data.py               # transforms and ImageFolder datasets
│   ├── model.py              # MobileNetV3-Small with new head
│   ├── train.py              # training loop, checkpoints, early stopping
│   ├── evaluate.py           # per-class precision / recall / F1 + confusion matrix
│   ├── predict.py            # Classifier class and CLI
│   ├── export.py             # ONNX export
│   └── ui.py                 # Gradio interface and CSV outcome log
├── scripts/
│   ├── make_demo_data.py     # synthetic images to smoke-test the pipeline
│   └── split_dataset.py      # raw class folders → train/ and val/
├── tests/test_core.py        # 15 unit tests (run without a GPU)
├── requirements.txt
└── Dockerfile
```

---

## 3. Quick start (about 10 minutes, no dataset needed)

Requires Python 3.10 or newer.

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 1. Run the unit tests (no torch needed for these)
python -m unittest -v

# 2. Create a tiny synthetic dataset to check the pipeline works
python scripts/make_demo_data.py --out data --per-class 40

# 3. Train (about a minute on CPU for the demo data)
python -m cropdoc.train --data data --out artifacts --epochs 5

# 4. Evaluate
python -m cropdoc.evaluate --ckpt artifacts/best.pt --data data

# 5. Launch the app → open http://localhost:7860
python app.py
```

> The demo images are synthetic, so the accuracy numbers mean nothing for real crops. Their only purpose is to prove the pipeline runs end to end.

---

## 4. Using a real dataset

**Option A: PlantVillage** (free, about 54,000 labelled leaf images across 38 classes; available on Kaggle).

```bash
# Download and unzip, so you have raw/<ClassName>/*.jpg
python scripts/split_dataset.py --src raw --dst data --val 0.2
python -m cropdoc.train --data data --out artifacts --epochs 15
python -m cropdoc.evaluate --ckpt artifacts/best.pt --data data
```

Then add advice for each new class name to `advice.json`. Class names are the folder names, for example `Tomato___Late_blight`. Anything missing falls back to a generic message.

**Option B: your own photos.** Put close-up photos of single leaves into `raw/<class>/`. Aim for 100 or more per class, taken in several lighting conditions, from the same kind of camera your users have.

---

## 5. Making the app trustworthy

| Setting | What it controls | How to choose it |
|---|---|---|
| `CROPDOC_THRESHOLD` (default `0.6`) | Minimum confidence before answering | Raise it (0.7–0.8) if wrong answers are costly. Check the rate of "not sure" on real photos |
| `MIN_SHARPNESS` in `cropdoc/quality.py` (default `50`) | Blur gate | Take 20 sharp and 20 blurry photos with your phone, print the scores, and set the cut-off between them |
| `MIN_BRIGHTNESS` (default `40`) | Dark-photo gate | Same method |

Run `python -m cropdoc.evaluate` on photos taken *outside* the training set (different farms, phones and light) before you trust the numbers.

---

## 6. Deploying

**Docker** (CPU only):
```bash
docker build -t cropdoc .
docker run -p 7860:7860 -v $(pwd)/artifacts:/app/artifacts cropdoc
```

**Edge or offline use:**
```bash
python -m cropdoc.export --ckpt artifacts/best.pt --out artifacts/cropdoc.onnx
```
The ONNX model takes a `[N, 3, 224, 224]` float tensor normalised with ImageNet mean and standard deviation, and returns logits. Load it with `onnxruntime` on Android, iOS, Raspberry Pi, or a browser.

**Logging:** each diagnosis appends a row to `history.csv` (timestamp, label, confidence, accepted). Photos are not stored. Use this file to spot which classes are often "not sure".

---

## 7. Limitations (please read before field use)

- **Lab photos are not field photos.** PlantVillage images are on plain backgrounds. Accuracy drops sharply on cluttered real-world images unless you add your own photos.
- **Not a diagnosis.** Treatment advice is generic. Pesticide choice depends on crop, region and local regulations, so the app says so and points users to an agronomist.
- **Unseen diseases.** The model can only pick from classes it was trained on. A new disease may be confidently mislabelled, which is why the confidence threshold and "not sure" path matter.
- **Thresholds are starting points.** Calibrate the blur, brightness and confidence settings on your own photos.

---

## 8. Ideas to extend

- Add a second model that rates severity (mild, moderate, severe).
- Support Hindi or regional-language advice via the `advice.json` file.
- Add a feedback button ("was this right?") and retrain on corrected labels.
- Put the ONNX model in a mobile app that works offline.
