"""Export the trained model to ONNX so it can run on phones, Raspberry Pi or
browsers without PyTorch.

Usage:
    python -m cropdoc.export --ckpt artifacts/best.pt --out artifacts/cropdoc.onnx
Run it with onnxruntime:  pip install onnxruntime
"""
from __future__ import annotations

import argparse

import torch

from .model import build_model


def export(ckpt_path: str, out_path: str) -> None:
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=True)
    model = build_model(len(ckpt["classes"]), pretrained=False)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    size = ckpt["img_size"]
    dummy = torch.randn(1, 3, size, size)
    torch.onnx.export(
        model, dummy, out_path,
        input_names=["image"], output_names=["logits"],
        dynamic_axes={"image": {0: "batch"}, "logits": {0: "batch"}},
        opset_version=17,
    )
    print(f"Exported {out_path}. Input: float32 [N, 3, {size}, {size}], "
          f"ImageNet-normalised. Output: logits for {ckpt['classes']}.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Export CropDoc to ONNX")
    parser.add_argument("--ckpt", default="artifacts/best.pt")
    parser.add_argument("--out", default="artifacts/cropdoc.onnx")
    args = parser.parse_args()
    export(args.ckpt, args.out)
