"""Gradio web interface: upload a leaf photo, get a diagnosis, advice and a log entry."""
from __future__ import annotations

import csv
import datetime as dt
import os

import gradio as gr

from .quality import check_quality

LOG_FIELDS = ["timestamp", "label", "confidence", "accepted"]


def _log(path: str, result: dict) -> None:
    """Append a row to a CSV log. The photo itself is never stored, only the outcome."""
    is_new = not os.path.exists(path)
    with open(path, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        if is_new:
            writer.writeheader()
        writer.writerow({
            "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
            "label": result["label"] or "",
            "confidence": result["confidence"],
            "accepted": result["accepted"],
        })


def build_ui(classifier, history_path: str = "history.csv") -> gr.Blocks:
    def diagnose(image):
        if image is None:
            return None, "Upload a photo of a single leaf to begin.", ""

        problems = check_quality(image)
        if problems:
            return None, (f"### Please retake the photo\n"
                          f"{'; '.join(problems).capitalize()}. Try daylight and a "
                          f"close, steady shot of one leaf."), ""

        result = classifier.predict(image)
        _log(history_path, result)

        scores = {item["label"].replace("_", " "): item["confidence"]
                  for item in result["top"]}
        if result["accepted"]:
            summary = (f"### {result['status']}: {result['label'].replace('_', ' ')}\n"
                       f"Model confidence: {result['confidence']:.0%}")
        else:
            summary = (f"### Not sure\nThe best guess is only "
                       f"{result['confidence']:.0%} confident. Try a clearer, close-up "
                       f"photo, or ask a local agronomist to look at the plant.")
        return scores, summary, result["advice"] or "No treatment advice for this result."

    with gr.Blocks(title="CropDoc - leaf disease detector") as demo:
        gr.Markdown("# CropDoc\nUpload a close-up photo of one leaf. "
                    "CropDoc suggests a likely disease and next steps. "
                    "It supports, but does not replace, advice from a local agronomist.")
        with gr.Row():
            with gr.Column():
                image_in = gr.Image(type="pil", label="Leaf photo", sources=["upload", "webcam"])
                run = gr.Button("Diagnose", variant="primary")
            with gr.Column():
                summary_out = gr.Markdown()
                scores_out = gr.Label(label="Top predictions", num_top_classes=3)
                advice_out = gr.Textbox(label="What to do next", lines=4, interactive=False)

        run.click(diagnose, inputs=image_in, outputs=[scores_out, summary_out, advice_out])
        image_in.change(diagnose, inputs=image_in, outputs=[scores_out, summary_out, advice_out])

    return demo
