"""Photo quality gate: reject photos that are too dark or too blurry to diagnose.

Real farm photos are often taken in poor light or with shaky hands. Checking
these before the model runs gives the farmer a useful message ("retake this")
instead of a misleading prediction.
"""
from __future__ import annotations

import numpy as np
from PIL import Image

MIN_BRIGHTNESS = 40.0   # mean grey level on a 0-255 scale
MIN_SHARPNESS = 50.0    # variance of the Laplacian; calibrate on your own photos


def check_quality(image: Image.Image, min_brightness=MIN_BRIGHTNESS,
                  min_sharpness=MIN_SHARPNESS) -> list[str]:
    """Return a list of human-readable problems. An empty list means the photo is fine."""
    grey = np.asarray(image.convert("L").resize((256, 256)), dtype=np.float32)

    brightness = float(grey.mean())
    # 4-neighbour Laplacian: sharp edges give large responses, blur gives small ones.
    laplacian = (-4 * grey[1:-1, 1:-1]
                 + grey[:-2, 1:-1] + grey[2:, 1:-1]
                 + grey[1:-1, :-2] + grey[1:-1, 2:])
    sharpness = float(laplacian.var())

    issues = []
    if brightness < min_brightness:
        issues.append("the photo is too dark")
    if sharpness < min_sharpness:
        issues.append("the photo looks blurry")
    return issues
