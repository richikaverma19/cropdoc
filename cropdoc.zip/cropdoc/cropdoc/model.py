"""MobileNetV3-Small with a new classification head (transfer learning).

MobileNetV3-Small is small enough to run on a mid-range Android phone or a
Raspberry Pi, which is why it was chosen over larger networks.
"""
from __future__ import annotations

from torch import nn
from torchvision import models

ARCH = "mobilenet_v3_small"


def build_model(num_classes: int, pretrained: bool = True,
                freeze_backbone: bool = False) -> nn.Module:
    weights = models.MobileNet_V3_Small_Weights.DEFAULT if pretrained else None
    model = models.mobilenet_v3_small(weights=weights)

    if freeze_backbone:
        # Only the new head learns; useful when you have very few images.
        for param in model.features.parameters():
            param.requires_grad = False

    # The last layer of the classifier maps to ImageNet's 1000 classes; swap it
    # for one that maps to our crop diseases.
    in_features = model.classifier[-1].in_features
    model.classifier[-1] = nn.Linear(in_features, num_classes)
    return model
