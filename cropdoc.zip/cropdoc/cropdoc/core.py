"""Framework-free logic: confidence decisions, dataset splitting and metrics.

Nothing here imports torch, so these pieces can be unit-tested anywhere.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass


def softmax(logits):
    """Convert raw model scores into probabilities that sum to 1."""
    m = max(logits)  # subtract the max for numerical stability
    exps = [math.exp(v - m) for v in logits]
    total = sum(exps)
    return [e / total for e in exps]


def top_k(probs, labels, k=3):
    """Return the k most likely (label, probability) pairs, highest first."""
    ranked = sorted(zip(labels, probs), key=lambda pair: pair[1], reverse=True)
    return ranked[:k]


@dataclass(frozen=True)
class Decision:
    label: str | None      # None means "not confident enough to answer"
    confidence: float
    accepted: bool


def decide(probs, labels, threshold=0.6):
    """Only answer when the top class clears the confidence threshold.

    In the real world an unfamiliar or badly framed photo should produce
    "not sure" rather than a confident wrong diagnosis.
    """
    (label, confidence), = top_k(probs, labels, k=1)
    accepted = confidence >= threshold
    return Decision(label if accepted else None, confidence, accepted)


def stratified_split(items_by_class, val_fraction=0.2, seed=42):
    """Split {class: [files]} into (train, val) lists of (file, class) pairs.

    Every class with at least two files contributes to validation, so the
    validation set never misses a class.
    """
    rng = random.Random(seed)
    train, val = [], []
    for label in sorted(items_by_class):
        files = list(items_by_class[label])
        rng.shuffle(files)
        n_val = max(1, round(len(files) * val_fraction)) if len(files) >= 2 else 0
        val.extend((f, label) for f in files[:n_val])
        train.extend((f, label) for f in files[n_val:])
    return train, val


def confusion_report(y_true, y_pred, classes):
    """Build a confusion matrix plus per-class precision, recall and F1."""
    n = len(classes)
    matrix = [[0] * n for _ in range(n)]
    for t, p in zip(y_true, y_pred):
        matrix[t][p] += 1

    per_class = []
    for i, name in enumerate(classes):
        tp = matrix[i][i]
        fp = sum(matrix[r][i] for r in range(n)) - tp
        fn = sum(matrix[i]) - tp
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        per_class.append({
            "class": name,
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "support": sum(matrix[i]),
        })

    total = len(y_true)
    accuracy = sum(matrix[i][i] for i in range(n)) / total if total else 0.0
    return {"accuracy": round(accuracy, 4), "per_class": per_class, "matrix": matrix}
