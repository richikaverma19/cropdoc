"""Load a trained checkpoint and diagnose a single photo.

Usage (command line):
    python -m cropdoc.predict path/to/leaf.jpg
"""
from __future__ import annotations

import json
import sys

import torch
from PIL import Image

from .core import decide, softmax, top_k
from .data import build_transforms
from .model import build_model

DEFAULT_ADVICE = {
    "_default": {
        "status": "Disease suspected",
        "advice": "Isolate affected plants, remove badly infected leaves, avoid "
                  "overhead watering, and check with a local agronomist before "
                  "applying any treatment.",
    }
}


class Classifier:
    def __init__(self, ckpt_path: str, advice_path: str | None = None,
                 threshold: float = 0.6, device: str | None = None):
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=True)

        self.classes = ckpt["classes"]
        self.threshold = threshold
        self.model = build_model(len(self.classes), pretrained=False)
        self.model.load_state_dict(ckpt["state_dict"])
        self.model.to(self.device).eval()

        _, self.transform = build_transforms(ckpt["img_size"])

        self.advice = DEFAULT_ADVICE
        if advice_path:
            with open(advice_path) as f:
                self.advice = {**DEFAULT_ADVICE, **json.load(f)}

    @torch.inference_mode()
    def predict(self, image: Image.Image) -> dict:
        x = self.transform(image.convert("RGB")).unsqueeze(0).to(self.device)
        logits = self.model(x)[0].cpu().tolist()
        probs = softmax(logits)

        decision = decide(probs, self.classes, self.threshold)
        entry = self.advice.get(decision.label or "", self.advice["_default"])

        return {
            "label": decision.label,
            "confidence": round(decision.confidence, 4),
            "accepted": decision.accepted,
            "top": [{"label": name, "confidence": round(p, 4)}
                    for name, p in top_k(probs, self.classes, k=3)],
            "status": entry["status"] if decision.accepted else "Not sure",
            "advice": entry["advice"] if decision.accepted else "",
        }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: python -m cropdoc.predict <image> [ckpt] [advice.json]")
    ckpt = sys.argv[2] if len(sys.argv) > 2 else "artifacts/best.pt"
    advice = sys.argv[3] if len(sys.argv) > 3 else "advice.json"
    clf = Classifier(ckpt, advice_path=advice)
    print(json.dumps(clf.predict(Image.open(sys.argv[1])), indent=2))
