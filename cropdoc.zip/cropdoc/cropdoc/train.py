"""Train the classifier.

Usage:
    python -m cropdoc.train --data data --out artifacts --epochs 15
"""
from __future__ import annotations

import argparse
import json
import os

import torch
from torch import nn
from torch.utils.data import DataLoader

from .data import build_datasets
from .model import ARCH, build_model


def run_epoch(model, loader, criterion, device, optimizer=None):
    """One pass over the data. Pass an optimizer to train, leave it None to evaluate."""
    training = optimizer is not None
    model.train(training)
    total, correct, loss_sum = 0, 0, 0.0

    with torch.set_grad_enabled(training):
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            logits = model(images)
            loss = criterion(logits, labels)
            if training:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            loss_sum += loss.item() * images.size(0)
            correct += (logits.argmax(1) == labels).sum().item()
            total += images.size(0)

    return loss_sum / max(total, 1), correct / max(total, 1)


def main():
    parser = argparse.ArgumentParser(description="Train CropDoc")
    parser.add_argument("--data", default="data")
    parser.add_argument("--out", default="artifacts")
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--img-size", type=int, default=224)
    parser.add_argument("--patience", type=int, default=4,
                        help="stop after this many epochs without validation gains")
    parser.add_argument("--no-pretrained", action="store_true",
                        help="skip ImageNet weights (only useful for offline smoke tests)")
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Training on {device}")

    train_ds, val_ds = build_datasets(args.data, args.img_size)
    classes = train_ds.classes
    print(f"Classes ({len(classes)}): {classes}")
    print(f"Train images: {len(train_ds)}  Val images: {len(val_ds)}")

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.workers)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                            num_workers=args.workers)

    model = build_model(len(classes), pretrained=not args.no_pretrained).to(device)
    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "classes.json"), "w") as f:
        json.dump(classes, f, indent=2)

    ckpt_path = os.path.join(args.out, "best.pt")
    history, best_acc, stale = [], -1.0, 0

    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = run_epoch(model, train_loader, criterion, device, optimizer)
        val_loss, val_acc = run_epoch(model, val_loader, criterion, device)
        scheduler.step()

        history.append({"epoch": epoch, "train_loss": train_loss, "train_acc": train_acc,
                        "val_loss": val_loss, "val_acc": val_acc})
        print(f"Epoch {epoch:02d} | train loss {train_loss:.3f} acc {train_acc:.3f} "
              f"| val loss {val_loss:.3f} acc {val_acc:.3f}")

        if val_acc > best_acc:
            best_acc, stale = val_acc, 0
            torch.save({
                "state_dict": model.state_dict(),
                "classes": classes,
                "img_size": args.img_size,
                "arch": ARCH,
            }, ckpt_path)
            print(f"  saved new best checkpoint ({best_acc:.3f})")
        else:
            stale += 1
            if stale >= args.patience:
                print("Early stopping: validation accuracy stopped improving.")
                break

    with open(os.path.join(args.out, "history.json"), "w") as f:
        json.dump(history, f, indent=2)
    print(f"Done. Best validation accuracy: {best_acc:.3f}. Checkpoint: {ckpt_path}")


if __name__ == "__main__":
    main()
