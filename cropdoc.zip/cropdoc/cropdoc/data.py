"""Image transforms and dataset loading.

Expected layout (created by scripts/split_dataset.py or scripts/make_demo_data.py):

    data/
      train/<class_name>/*.jpg
      val/<class_name>/*.jpg
"""
from __future__ import annotations

import os

from torchvision import datasets, transforms

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def build_transforms(img_size: int = 224):
    """Training uses augmentation; evaluation uses a deterministic crop."""
    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(img_size, scale=(0.7, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    eval_tf = transforms.Compose([
        transforms.Resize(int(img_size * 1.14)),
        transforms.CenterCrop(img_size),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    return train_tf, eval_tf


def build_datasets(data_dir: str, img_size: int = 224):
    train_tf, eval_tf = build_transforms(img_size)
    train_ds = datasets.ImageFolder(os.path.join(data_dir, "train"), transform=train_tf)
    val_ds = datasets.ImageFolder(os.path.join(data_dir, "val"), transform=eval_tf)
    if train_ds.classes != val_ds.classes:
        raise ValueError(
            f"Train and val class folders differ: {train_ds.classes} vs {val_ds.classes}"
        )
    return train_ds, val_ds
