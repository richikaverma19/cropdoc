"""Evaluate a trained checkpoint on the validation set and print a report.

Usage:
    python -m cropdoc.evaluate --ckpt artifacts/best.pt --data data
"""
from __future__ import annotations

import argparse
import json

import torch
from torch.utils.data import DataLoader

from .core import confusion_report
from .data import build_datasets
from .model import build_model


def main():
    parser = argparse.ArgumentParser(description="Evaluate CropDoc")
    parser.add_argument("--ckpt", default="artifacts/best.pt")
    parser.add_argument("--data", default="data")
    parser.add_argument("--out", default="artifacts/report.json")
    parser.add_argument("--batch-size", type=int, default=32)
    args = parser.parse_args()

    ckpt = torch.load(args.ckpt, map_location="cpu", weights_only=True)
    classes = ckpt["classes"]
    model = build_model(len(classes), pretrained=False)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    _, val_ds = build_datasets(args.data, ckpt["img_size"])
    loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

    y_true, y_pred = [], []
    with torch.inference_mode():
        for images, labels in loader:
            preds = model(images).argmax(1)
            y_true.extend(labels.tolist())
            y_pred.extend(preds.tolist())

    report = confusion_report(y_true, y_pred, classes)
    print(f"Validation accuracy: {report['accuracy']:.3f}\n")
    print(f"{'class':<28}{'precision':>10}{'recall':>10}{'f1':>10}{'n':>6}")
    for row in report["per_class"]:
        print(f"{row['class']:<28}{row['precision']:>10.3f}{row['recall']:>10.3f}"
              f"{row['f1']:>10.3f}{row['support']:>6}")

    with open(args.out, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\nFull report saved to {args.out}")


if __name__ == "__main__":
    main()
