"""CropDoc: detect common leaf diseases from a phone photo."""

__version__ = "1.0.0"
